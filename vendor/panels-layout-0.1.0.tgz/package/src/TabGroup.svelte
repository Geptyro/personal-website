<svelte:options runes={false} />

<script>
  import { get } from 'svelte/store';
  import {
    getPanelList, getPanelComponent,
    setActiveGroup, setActiveTab, setGroupMode, addTab, closeTab, moveTab, splitGroup, splitAndMoveTab, splitAtAncestor,
    activeGroupId, dragState, dropTarget,
  } from './store.js';

  export let group;
  export let onContextMenu = null; // (x, y, items) => void — injected from root

  const PANEL_LIST = getPanelList();
  const DEFAULT_SPLIT_PANEL = PANEL_LIST[0]?.type ?? 'Panel';

  $: isActive = $activeGroupId === group.id;

  // ── Context menu (simple inline) ──────────────────────────────────────────
  let ctxMenu = null; // { x, y, items }

  function showCtx(x, y, items) {
    // Use injected handler if available, else fall back to inline
    if (onContextMenu) { onContextMenu(x, y, items); return; }
    ctxMenu = { x, y, items };
  }
  function hideCtx() { ctxMenu = null; }

  // ── Tab interaction ───────────────────────────────────────────────────────

  function onTabClick(e, tab) {
    e.stopPropagation();
    setActiveTab(group.id, tab.id);
  }

  function onTabClose(e, tab) {
    e.stopPropagation();
    closeTab(group.id, tab.id);
  }

  function reloadTab(tab) {
    reloadTokens[tab.id] = (reloadTokens[tab.id] ?? 0) + 1;
    reloadTokens = reloadTokens;
  }
  let reloadTokens = {}; // tabId → reload counter (forces component remount via {#key})

  function onTabContextMenu(e, tab) {
    e.preventDefault();
    showCtx(e.clientX, e.clientY, [
      { label: 'Reload', action: () => reloadTab(tab)              },
      { separator: true },
      { label: 'Close',  action: () => closeTab(group.id, tab.id) },
    ]);
  }

  // ── Tab drag ─────────────────────────────────────────────────────────────

  function onTabPointerDown(e, tab) {
    if (e.button !== 0) return;
    // Don't prevent default — tab click still works if no drag occurs
    const startX = e.clientX, startY = e.clientY;
    let dragging = false;
    let ghost = null;

    function onMove(e) {
      if (!dragging) {
        if (Math.hypot(e.clientX - startX, e.clientY - startY) > 5) {
          dragging = true;
          ghost = document.createElement('div');
          ghost.className = 'tab-drag-ghost';
          ghost.textContent = tab.title;
          document.body.appendChild(ghost);
          document.body.classList.add('layout-dragging-tab');
          dragState.set({ tabId: tab.id, fromGroupId: group.id, title: tab.title });
        }
      }
      if (!dragging) return;

      ghost.style.left = (e.clientX + 10) + 'px';
      ghost.style.top  = (e.clientY - 12) + 'px';

      // Detect what's under the cursor
      const els        = document.elementsFromPoint(e.clientX, e.clientY);
      const bar        = els.find(el => el.dataset.groupId);
      const contentEl  = !bar && els.find(el => el.dataset.groupContentId);

      if (bar) {
        // ── Tab bar: compute insert index ───────────────────────────────────
        const toGroupId = bar.dataset.groupId;
        const tabEls = [...bar.querySelectorAll('[data-tab-idx]')];
        let idx = tabEls.length;
        for (const tabEl of tabEls) {
          const r = tabEl.getBoundingClientRect();
          if (e.clientX < r.left + r.width / 2) { idx = parseInt(tabEl.dataset.tabIdx, 10); break; }
        }
        dropTarget.set({ type: 'tab', groupId: toGroupId, index: idx });
      } else if (contentEl) {
        // ── Content area: compute split zone (25% edge bands) ───────────────
        const gid  = contentEl.dataset.groupContentId;
        // Can't split a group that only contains the tab being dragged
        const isSingleTabSelf = gid === group.id && group.tabs.length <= 1;
        const rect = contentEl.getBoundingClientRect();
        const px   = e.clientX - rect.left;
        const py   = e.clientY - rect.top;
        const W    = rect.width;
        const H    = rect.height;
        // Depth-2 band: 0–10% from edge. Depth-1 band: 10–40% from edge.
        const D2 = 0.10, D1 = 0.40;

        if (isSingleTabSelf) {
          dropTarget.set(null);
        } else if (px < W * D2)              dropTarget.set({ type: 'split', groupId: gid, dir: 'h', side: 'a', depth: 2 });
        else if (px < W * D1)                dropTarget.set({ type: 'split', groupId: gid, dir: 'h', side: 'a', depth: 1 });
        else if (px > W * (1 - D2))          dropTarget.set({ type: 'split', groupId: gid, dir: 'h', side: 'b', depth: 2 });
        else if (px > W * (1 - D1))          dropTarget.set({ type: 'split', groupId: gid, dir: 'h', side: 'b', depth: 1 });
        else if (py < H * D2)                dropTarget.set({ type: 'split', groupId: gid, dir: 'v', side: 'a', depth: 2 });
        else if (py < H * D1)                dropTarget.set({ type: 'split', groupId: gid, dir: 'v', side: 'a', depth: 1 });
        else if (py > H * (1 - D2))          dropTarget.set({ type: 'split', groupId: gid, dir: 'v', side: 'b', depth: 2 });
        else if (py > H * (1 - D1))          dropTarget.set({ type: 'split', groupId: gid, dir: 'v', side: 'b', depth: 1 });
        else                                 dropTarget.set({ type: 'tab',   groupId: gid, index: 9999 });
      } else {
        dropTarget.set(null);
      }
    }

    function onUp(e) {
      document.removeEventListener('pointermove', onMove);
      document.removeEventListener('pointerup',   onUp);
      ghost?.remove();
      document.body.classList.remove('layout-dragging-tab');

      const ds = get(dragState);
      const dt = get(dropTarget);
      dragState.set(null);
      dropTarget.set(null);

      if (dragging && ds && dt) {
        if (dt.type === 'split') {
          if (dt.depth === 2) {
            splitAtAncestor(ds.fromGroupId, ds.tabId, dt.groupId, dt.dir, dt.side);
          } else {
            splitAndMoveTab(ds.fromGroupId, ds.tabId, dt.groupId, dt.dir, dt.side);
          }
        } else {
          moveTab(ds.fromGroupId, ds.tabId, dt.groupId, dt.index);
        }
      }
    }

    document.addEventListener('pointermove', onMove);
    document.addEventListener('pointerup',   onUp);
  }

  // ── Add panel menu ────────────────────────────────────────────────────────
  let showAddMenu = false;
  let addMenuEl;

  function toggleAddMenu(e) {
    e.stopPropagation();
    showAddMenu = !showAddMenu;
  }

  function addPanel(type) {
    addTab(group.id, type);
    showAddMenu = false;
  }

  function onDocClick(e) {
    if (showAddMenu && addMenuEl && !addMenuEl.contains(e.target)) showAddMenu = false;
  }
</script>

<svelte:document on:click={onDocClick} />

<!-- svelte-ignore a11y-no-static-element-interactions -->
<div
  class="tab-group"
  class:active={isActive}
  on:pointerdown={() => setActiveGroup(group.id)}
>
  <!-- Tab bar -->
  <div class="tab-bar" data-group-id={group.id}>
    {#each group.tabs as tab, i (tab.id)}
      {#if $dragState && $dropTarget?.type === 'tab' && $dropTarget?.groupId === group.id && $dropTarget?.index === i}
        <div class="drop-line"></div>
      {/if}
      <!-- svelte-ignore a11y-no-static-element-interactions -->
      <div
        class="tab"
        class:tab--active={tab.id === group.active}
        class:tab--dragging={$dragState?.tabId === tab.id}
        data-tab-idx={i}
        on:click={(e) => onTabClick(e, tab)}
        on:pointerdown={(e) => onTabPointerDown(e, tab)}
        on:contextmenu={(e) => onTabContextMenu(e, tab)}
      >
        <span class="tab-title">{tab.title}</span>
        <button class="tab-close" on:click={(e) => onTabClose(e, tab)}>×</button>
      </div>
    {/each}

    {#if $dragState && $dropTarget?.type === 'tab' && $dropTarget?.groupId === group.id && $dropTarget?.index >= group.tabs.length}
      <div class="drop-line"></div>
    {/if}

    <!-- Mode toggle -->
    <button
      class="mode-btn"
      title={group.mode === 'stack' ? 'Switch to tabs' : 'Switch to stack'}
      on:click={(e) => { e.stopPropagation(); setGroupMode(group.id, group.mode === 'stack' ? 'tabs' : 'stack'); }}
    >{group.mode === 'stack' ? '▤' : '▦'}</button>

    <!-- Add button -->
    <div class="add-wrap" bind:this={addMenuEl}>
      <button class="add-btn" on:click={toggleAddMenu} title="Add panel">+</button>
      {#if showAddMenu}
        <div class="add-menu">
          {#each PANEL_LIST as p}
            <button class="add-item" on:click={() => addPanel(p.type)}>{p.label}</button>
          {/each}
          <div class="add-sep"></div>
          <button class="add-item" on:click={() => { splitGroup(group.id, 'h', DEFAULT_SPLIT_PANEL); showAddMenu = false; }}>Split right →</button>
          <button class="add-item" on:click={() => { splitGroup(group.id, 'v', DEFAULT_SPLIT_PANEL); showAddMenu = false; }}>Split down ↓</button>
        </div>
      {/if}
    </div>
  </div>

  <!-- Content: tabs mode = overlapping iframes, stack mode = vertical scroll -->
  <div class="tab-content" class:tab-content--stack={group.mode === 'stack'} data-group-content-id={group.id}>
    <!-- Split drop indicator -->
    {#if $dragState && $dropTarget?.type === 'split' && $dropTarget?.groupId === group.id}
      {@const dt = $dropTarget}
      <div class="split-indicator split-indicator--{dt.dir}-{dt.side}" class:split-indicator--outer={dt.depth === 2}>
        <span class="split-indicator-label">
          {dt.depth === 2 ? '⇥ ' : ''}{dt.dir === 'h' ? (dt.side === 'a' ? '← Split left' : 'Split right →') : (dt.side === 'a' ? '↑ Split top' : 'Split bottom ↓')}
        </span>
      </div>
    {/if}
    {#if group.mode === 'stack'}
      {#each group.tabs as tab (tab.id)}
        <div class="stack-item">
          <div class="stack-head">
            <span class="stack-title">{tab.title}</span>
            <button class="stack-close" on:click={(e) => onTabClose(e, tab)}>×</button>
          </div>
          <div class="stack-body">
            {#key reloadTokens[tab.id] ?? 0}
              <svelte:component this={getPanelComponent(tab.panelType)} />
            {/key}
          </div>
        </div>
      {/each}
    {:else}
      {#each group.tabs as tab (tab.id)}
        <div
          class="tab-pane"
          class:tab-pane--active={tab.id === group.active}
        >
          {#key reloadTokens[tab.id] ?? 0}
            <svelte:component this={getPanelComponent(tab.panelType)} />
          {/key}
        </div>
      {/each}
    {/if}
  </div>
</div>

<!-- Inline context menu (used when no external handler provided) -->
{#if ctxMenu}
  <!-- svelte-ignore a11y-no-static-element-interactions a11y-click-events-have-key-events -->
  <div class="ctx-overlay" on:click={hideCtx} on:contextmenu|preventDefault={hideCtx}></div>
  <div class="ctx-menu" style="left:{ctxMenu.x}px;top:{ctxMenu.y}px">
    {#each ctxMenu.items as item}
      {#if item.separator}
        <div class="ctx-sep"></div>
      {:else}
        <button class="ctx-item" on:click={() => { item.action(); hideCtx(); }}>{item.label}</button>
      {/if}
    {/each}
  </div>
{/if}

<style>
  .tab-group {
    display: flex;
    flex-direction: column;
    width: 100%;
    height: 100%;
    overflow: hidden;
    background: var(--bg);
  }

  /* Tab bar */
  .tab-bar {
    display: flex;
    align-items: stretch;
    flex-shrink: 0;
    background: var(--bg-card2);
    border-bottom: 1px solid var(--border);
    overflow-x: auto;
    overflow-y: hidden;
    scrollbar-width: none;
    height: 30px;
  }
  .tab-bar::-webkit-scrollbar { display: none; }

  .tab {
    display: flex;
    align-items: center;
    gap: 4px;
    padding: 0 10px 0 12px;
    font-size: 0.68rem;
    color: var(--text-muted);
    border-right: 1px solid var(--border);
    cursor: pointer;
    user-select: none;
    white-space: nowrap;
    flex-shrink: 0;
    transition: background 0.1s, color 0.1s;
  }
  .tab:hover { background: var(--bg-card); color: var(--text); }
  .tab--active {
    background: var(--bg);
    color: var(--text);
    border-bottom: 2px solid var(--accent);
  }
  .tab--dragging { opacity: 0.4; }

  .tab-title { pointer-events: none; }

  .tab-close {
    font-size: 0.8rem; line-height: 1;
    background: none; border: none; color: inherit;
    cursor: pointer; padding: 0 0 0 2px; opacity: 0.4;
    transition: opacity 0.1s;
    font-family: inherit;
  }
  .tab-close:hover { opacity: 1; }

  /* Drop indicator */
  .drop-line {
    width: 2px;
    height: 22px;
    background: var(--accent);
    align-self: center;
    border-radius: 1px;
    flex-shrink: 0;
    margin: 0 1px;
  }

  /* Add button */
  .add-wrap {
    position: relative;
    display: flex;
    align-items: center;
  }
  .add-btn {
    height: 100%;
    padding: 0 10px;
    background: none; border: none;
    color: var(--text-dim); font-size: 1rem; line-height: 1;
    cursor: pointer; font-family: inherit;
    transition: color 0.1s;
  }
  .add-btn:hover { color: var(--accent); }

  .add-menu {
    position: absolute;
    top: 100%; left: 0;
    background: var(--bg-card2);
    border: 1px solid var(--border);
    border-radius: 4px;
    z-index: 500;
    min-width: 130px;
    padding: 3px 0;
    box-shadow: 0 6px 20px rgba(0,0,0,.5);
  }
  .add-item {
    display: block; width: 100%;
    font-family: inherit; font-size: 0.65rem;
    background: none; border: none; text-align: left;
    color: var(--text-muted); padding: 5px 14px; cursor: pointer;
  }
  .add-item:hover { color: var(--accent); background: var(--accent-bg); }
  .add-sep { height: 1px; background: var(--border); margin: 3px 0; }

  /* Panel content */
  .tab-content {
    flex: 1;
    position: relative;
    overflow: hidden;
  }
  .tab-content--stack {
    overflow-y: auto;
    overflow-x: hidden;
    scrollbar-width: thin;
  }
  .tab-pane {
    position: absolute;
    inset: 0;
    overflow: auto;
    display: none;
  }
  .tab-pane--active { display: block; }

  /* Stack mode */
  .stack-item {
    border-bottom: 1px solid var(--border);
  }
  .stack-head {
    display: flex; align-items: center; gap: 6px;
    padding: 4px 10px;
    background: var(--bg-card2);
    border-bottom: 1px solid var(--border);
    position: sticky; top: 0; z-index: 5;
  }
  .stack-title {
    font-size: 0.62rem; font-weight: 700;
    text-transform: uppercase; letter-spacing: 0.07em;
    color: var(--text-muted); flex: 1;
  }
  .stack-close {
    background: none; border: none; cursor: pointer;
    color: var(--text-dim); font-size: 0.85rem; line-height: 1;
    padding: 0 4px; opacity: 0.5;
  }
  .stack-close:hover { opacity: 1; color: var(--text); }
  .stack-body {
    display: block;
    width: 100%;
  }

  /* Mode toggle */
  .mode-btn {
    height: 100%;
    padding: 0 10px;
    background: none; border: none;
    color: var(--text-dim); font-size: 0.9rem; line-height: 1;
    cursor: pointer; font-family: inherit;
    transition: color 0.1s;
  }
  .mode-btn:hover { color: var(--accent); }

  /* Split drop indicator */
  .split-indicator {
    position: absolute;
    z-index: 200;
    pointer-events: none;
    background: color-mix(in srgb, var(--accent) 18%, transparent);
    border: 2px solid var(--accent);
    display: flex;
    align-items: center;
    justify-content: center;
    transition: inset 0.08s;
  }
  .split-indicator--h-a { inset: 0 50% 0 0; }
  .split-indicator--h-b { inset: 0 0 0 50%; }
  .split-indicator--v-a { inset: 0 0 50% 0; }
  .split-indicator--v-b { inset: 50% 0 0 0; }

  .split-indicator--outer {
    background: color-mix(in srgb, var(--accent) 28%, transparent);
    border-width: 3px;
  }
  .split-indicator-label {
    font-size: 0.65rem;
    font-weight: 700;
    color: var(--accent);
    background: var(--bg-card2);
    padding: 3px 8px;
    border-radius: 3px;
    border: 1px solid var(--accent);
    white-space: nowrap;
  }

  /* Inline context menu */
  .ctx-overlay {
    position: fixed; inset: 0; z-index: 9998;
  }
  .ctx-menu {
    position: fixed; z-index: 9999;
    background: var(--bg-card2); border: 1px solid var(--border);
    border-radius: 4px; padding: 3px 0;
    box-shadow: 0 6px 20px rgba(0,0,0,.5);
    min-width: 160px;
  }
  .ctx-item {
    display: block; width: 100%;
    font-family: inherit; font-size: 0.65rem;
    background: none; border: none; text-align: left;
    color: var(--text-muted); padding: 5px 14px; cursor: pointer;
  }
  .ctx-item:hover { background: var(--accent-bg); color: var(--accent); }
  .ctx-sep { height: 1px; background: var(--border); margin: 3px 0; }
</style>
