import { writable, get } from 'svelte/store';

// ── Config ────────────────────────────────────────────────────────────────
// Must be set via configureLayout() before any action is called.

let _config = null;

export function configureLayout({ panelList, buildDefault, storageKey, components }) {
  if (!panelList || !buildDefault || !storageKey || !components) {
    throw new Error('configureLayout requires { panelList, buildDefault, storageKey, components }');
  }
  _config = { panelList, buildDefault, storageKey, components };

  // Initialize stores now that config is available
  const saved = _load();
  layout.set(saved ?? buildDefault());
  const groups = allGroups(get(layout));
  if (groups[0]) activeGroupId.set(groups[0].id);
}

function cfg() {
  if (!_config) throw new Error('panels-layout: configureLayout() must be called before use');
  return _config;
}

// Exposed as a getter so host code can read the current list
export function getPanelList() { return cfg().panelList; }

export function getPanelComponent(type) { return cfg().components[type] ?? null; }

// ── ID generation ─────────────────────────────────────────────────────────────

function uid(prefix = '') {
  return prefix + Math.random().toString(36).slice(2, 9);
}

// ── Node factories ────────────────────────────────────────────────────────────

function makeTab(panelType, state) {
  const panel = cfg().panelList.find(p => p.type === panelType);
  const tab = { id: uid('t'), panelType, title: panel?.label ?? panelType };
  if (state) tab.state = { ...state };
  return tab;
}

function makeGroup(panelTypes = [], mode = 'tabs') {
  const tabs = panelTypes.map(t =>
    typeof t === 'string' ? makeTab(t) : makeTab(t.type, t.state)
  );
  return { type: 'tabs', id: uid('g'), mode, tabs, active: tabs[0]?.id ?? null };
}

function makeSplit(dir, ratio, a, b) {
  return { type: 'split', id: uid('s'), dir, ratio, a, b };
}

// Helper exposed for host apps to build their default tree
export const nodeFactories = { makeTab, makeGroup, makeSplit };

// ── Tree helpers ──────────────────────────────────────────────────────────────

function updateNode(node, id, fn) {
  if (!node) return node;
  if (node.id === id) return fn(node);
  if (node.type === 'split') {
    return { ...node, a: updateNode(node.a, id, fn), b: updateNode(node.b, id, fn) };
  }
  return node;
}

function allGroups(node, out = []) {
  if (!node) return out;
  if (node.type === 'tabs') { out.push(node); return out; }
  allGroups(node.a, out);
  allGroups(node.b, out);
  return out;
}

function clean(node) {
  if (!node) return null;
  if (node.type === 'tabs') return node.tabs.length ? node : null;
  const a = clean(node.a), b = clean(node.b);
  if (!a && !b) return null;
  if (!a) return b;
  if (!b) return a;
  return { ...node, a, b };
}

// ── Persistence ───────────────────────────────────────────────────────────────

function backfillMode(node) {
  if (!node) return node;
  if (node.type === 'tabs') return { ...node, mode: node.mode ?? 'tabs' };
  if (node.type === 'split') return { ...node, a: backfillMode(node.a), b: backfillMode(node.b) };
  return node;
}

function _load() {
  try {
    const raw = localStorage.getItem(cfg().storageKey);
    if (raw) return backfillMode(JSON.parse(raw));
  } catch {}
  return null;
}

// ── Stores ────────────────────────────────────────────────────────────────────

export const layout         = writable(null);
export const activeGroupId  = writable(null);
export const dragState      = writable(null);
export const dropTarget     = writable(null);

let _saveTimer;
layout.subscribe(tree => {
  if (!tree || !_config) return;
  clearTimeout(_saveTimer);
  _saveTimer = setTimeout(() => {
    try { localStorage.setItem(_config.storageKey, JSON.stringify(tree)); } catch {}
  }, 200);
});

// ── Actions ───────────────────────────────────────────────────────────────────

export function setActiveGroup(id) {
  activeGroupId.set(id);
}

export function setActiveTab(groupId, tabId) {
  layout.update(tree => updateNode(tree, groupId, g => ({ ...g, active: tabId })));
  activeGroupId.set(groupId);
}

export function setGroupMode(groupId, mode) {
  layout.update(tree => updateNode(tree, groupId, g => ({ ...g, mode })));
}

export function addTab(groupId, panelType, state) {
  const tab = makeTab(panelType, state);
  layout.update(tree => updateNode(tree, groupId, g => ({
    ...g, tabs: [...g.tabs, tab], active: tab.id,
  })));
  activeGroupId.set(groupId);
  return tab;
}

export function closeTab(groupId, tabId) {
  layout.update(tree => {
    const updated = updateNode(tree, groupId, g => {
      const idx  = g.tabs.findIndex(t => t.id === tabId);
      const tabs = g.tabs.filter(t => t.id !== tabId);
      const active = g.active === tabId
        ? (tabs[Math.min(idx, tabs.length - 1)]?.id ?? null)
        : g.active;
      return { ...g, tabs, active };
    });
    const next = clean(updated) ?? cfg().buildDefault();
    const groups = allGroups(next);
    if (!groups.find(g => g.id === get(activeGroupId))) {
      activeGroupId.set(groups[0]?.id ?? null);
    }
    return next;
  });
}

export function moveTab(fromGroupId, tabId, toGroupId, toIndex) {
  layout.update(tree => {
    const srcGroup = allGroups(tree).find(g => g.id === fromGroupId);
    const tab = srcGroup?.tabs.find(t => t.id === tabId);
    if (!tab) return tree;

    let t = updateNode(tree, fromGroupId, g => {
      const tabs = g.tabs.filter(t => t.id !== tabId);
      const active = g.active === tabId ? (tabs[0]?.id ?? null) : g.active;
      return { ...g, tabs, active };
    });

    t = updateNode(t, toGroupId, g => {
      const tabs = [...g.tabs];
      tabs.splice(Math.max(0, Math.min(toIndex, tabs.length)), 0, tab);
      return { ...g, tabs, active: tab.id };
    });

    return clean(t) ?? cfg().buildDefault();
  });
  activeGroupId.set(toGroupId);
}

export function setRatio(splitId, delta, total) {
  layout.update(tree => updateNode(tree, splitId, s => ({
    ...s, ratio: Math.max(0.05, Math.min(0.95, s.ratio + delta / total)),
  })));
}

export function splitGroup(groupId, dir, panelType) {
  const newGroup = makeGroup([panelType]);
  layout.update(tree => {
    function go(node) {
      if (!node) return node;
      if (node.id === groupId) return makeSplit(dir, 0.5, node, newGroup);
      if (node.type === 'split') return { ...node, a: go(node.a), b: go(node.b) };
      return node;
    }
    return go(tree);
  });
  activeGroupId.set(newGroup.id);
}

function resolveActiveGroup(groups) {
  const cur = get(activeGroupId);
  return groups.find(g => g.id === cur)?.id ?? groups[0]?.id ?? null;
}

export function openOrFocus(panelType, state) {
  const tree   = get(layout);
  const groups = allGroups(tree);
  if (!groups.length) return;

  for (const g of groups) {
    const tab = g.tabs.find(t => t.panelType === panelType);
    if (tab) { setActiveTab(g.id, tab.id); return; }
  }

  const gid = resolveActiveGroup(groups);
  if (gid) addTab(gid, panelType, state);
}

export function getAllGroups() {
  return allGroups(get(layout));
}

function ancestorSplits(node, groupId, path = []) {
  if (!node) return null;
  if (node.type === 'tabs') return node.id === groupId ? path : null;
  return ancestorSplits(node.a, groupId, [...path, node])
      ?? ancestorSplits(node.b, groupId, [...path, node]);
}

export function splitAtAncestor(fromGroupId, tabId, targetGroupId, dir, side) {
  const tree = get(layout);

  const path     = ancestorSplits(tree, targetGroupId) ?? [];
  const ancestor = [...path].reverse().find(n => n.dir === dir) ?? null;

  let srcGroup = allGroups(tree).find(g => g.id === fromGroupId);
  const tab    = srcGroup?.tabs.find(t => t.id === tabId);
  if (!tab) return;

  const newGroup = { type: 'tabs', id: uid('g'), tabs: [tab], active: tab.id };

  layout.update(tree => {
    let t = updateNode(tree, fromGroupId, g => {
      const tabs   = g.tabs.filter(t => t.id !== tabId);
      const active = g.active === tabId ? (tabs[0]?.id ?? null) : g.active;
      return { ...g, tabs, active };
    });

    if (ancestor) {
      t = updateNode(t, ancestor.id, n =>
        side === 'b'
          ? makeSplit(dir, 0.5, n, newGroup)
          : makeSplit(dir, 0.5, newGroup, n)
      );
    } else {
      t = updateNode(t, targetGroupId, n =>
        side === 'b'
          ? makeSplit(dir, 0.5, n, newGroup)
          : makeSplit(dir, 0.5, newGroup, n)
      );
    }

    return clean(t) ?? cfg().buildDefault();
  });

  activeGroupId.set(newGroup.id);
}

export function splitAndMoveTab(fromGroupId, tabId, targetGroupId, dir, side) {
  layout.update(tree => {
    const srcGroup = allGroups(tree).find(g => g.id === fromGroupId);
    const tab = srcGroup?.tabs.find(t => t.id === tabId);
    if (!tab) return tree;
    if (fromGroupId === targetGroupId && srcGroup.tabs.length <= 1) return tree;

    let t = updateNode(tree, fromGroupId, g => {
      const tabs = g.tabs.filter(t => t.id !== tabId);
      const active = g.active === tabId ? (tabs[0]?.id ?? null) : g.active;
      return { ...g, tabs, active };
    });

    const newGroup = { type: 'tabs', id: uid('g'), tabs: [tab], active: tab.id };

    t = updateNode(t, targetGroupId, g =>
      side === 'a'
        ? makeSplit(dir, 0.5, newGroup, g)
        : makeSplit(dir, 0.5, g, newGroup)
    );

    return clean(t) ?? cfg().buildDefault();
  });
}

export function resetLayout() {
  const fresh = cfg().buildDefault();
  layout.set(fresh);
  const groups = allGroups(fresh);
  if (groups[0]) activeGroupId.set(groups[0].id);
}
