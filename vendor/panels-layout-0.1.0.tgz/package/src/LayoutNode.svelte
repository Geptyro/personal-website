<svelte:options runes={false} />

<script>
  import Splitter  from './Splitter.svelte';
  import TabGroup  from './TabGroup.svelte';

  export let node;

  let el;
  // getSize passed to Splitter so it can read the live pixel size
  function getSize() {
    if (!el) return 0;
    return node.dir === 'h' ? el.clientWidth : el.clientHeight;
  }
</script>

{#if node.type === 'split'}
  <div bind:this={el} class="split split--{node.dir}">
    <div
      class="child"
      style="{node.dir === 'h' ? 'width' : 'height'}:{node.ratio * 100}%"
    >
      <svelte:self node={node.a} />
    </div>

    <Splitter dir={node.dir} splitId={node.id} {getSize} />

    <div class="child child--flex">
      <svelte:self node={node.b} />
    </div>
  </div>
{:else if node.type === 'tabs'}
  <TabGroup group={node} />
{/if}

<style>
  .split {
    display: flex;
    width: 100%;
    height: 100%;
    overflow: hidden;
  }
  .split--v { flex-direction: column; }

  .child {
    min-width: 0;
    min-height: 0;
    overflow: hidden;
  }
  .child--flex { flex: 1; }
</style>
