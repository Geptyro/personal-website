<svelte:options runes={false} />

<script>
  export let dir;    // 'h' | 'v'
  export let splitId;
  export let getSize; // () => number — current pixel size of the container

  import { setRatio } from './store.js';

  let el;
  let active = false;

  function onPointerDown(e) {
    if (e.button !== 0) return;
    e.preventDefault();
    el.setPointerCapture(e.pointerId);
    active = true;
    document.body.style.userSelect = 'none';
  }

  function onPointerMove(e) {
    if (!active) return;
    const delta = dir === 'h' ? e.movementX : e.movementY;
    const total = getSize();
    if (total > 0) setRatio(splitId, delta, total);
  }

  function onRelease() {
    active = false;
    document.body.style.userSelect = '';
  }
</script>

<!-- svelte-ignore a11y-no-static-element-interactions -->
<div
  bind:this={el}
  class="splitter splitter--{dir}"
  class:active
  on:pointerdown={onPointerDown}
  on:pointermove={onPointerMove}
  on:pointerup={onRelease}
  on:lostpointercapture={onRelease}
></div>

<style>
  .splitter {
    flex: 0 0 3px;
    background: var(--border);
    transition: background 0.12s;
    position: relative;
    z-index: 10;
  }
  /* Expand hit area without affecting layout */
  .splitter::after {
    content: '';
    position: absolute;
  }
  .splitter--h {
    cursor: col-resize;
  }
  .splitter--h::after { inset: 0 -4px; }
  .splitter--v {
    cursor: row-resize;
  }
  .splitter--v::after { inset: -4px 0; }
  .splitter:hover, .splitter.active { background: var(--accent); }
</style>
